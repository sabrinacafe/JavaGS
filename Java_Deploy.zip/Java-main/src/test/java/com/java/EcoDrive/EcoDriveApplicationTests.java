/*package com.java.EcoDrive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoDriveApplicationTests {

	@Test
	void contextLoads() {
	}

}*/

