package com.java.EcoDrive.dto.Bairro;

public class BairroDTO {

    private Long bairroId;
    private String nome;

    // Getters e Setters

    public Long getBairroId() {
        return bairroId;
    }

    public void setBairroId(Long bairroId) {
        this.bairroId = bairroId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
