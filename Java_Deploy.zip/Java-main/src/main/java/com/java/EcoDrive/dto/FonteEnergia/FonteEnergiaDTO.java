package com.java.EcoDrive.dto.FonteEnergia;

public class FonteEnergiaDTO {

    private Long fonteId;
    private String tipoEnergia;

    // Getters e Setters

    public Long getFonteId() {
        return fonteId;
    }

    public void setFonteId(Long fonteId) {
        this.fonteId = fonteId;
    }

    public String getTipoEnergia() {
        return tipoEnergia;
    }

    public void setTipoEnergia(String tipoEnergia) {
        this.tipoEnergia = tipoEnergia;
    }
}
