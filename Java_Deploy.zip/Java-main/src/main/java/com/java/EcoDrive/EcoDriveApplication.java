package com.java.EcoDrive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcoDriveApplication {
	public static void main(String[] args) {
		SpringApplication.run(EcoDriveApplication.class, args);
	}
}


